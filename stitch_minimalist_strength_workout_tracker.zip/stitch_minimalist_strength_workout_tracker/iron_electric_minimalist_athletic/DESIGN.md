---
name: Iron & Electric Minimalist Athletic
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#c3c9ae'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#8d937b'
  outline-variant: '#434934'
  surface-tint: '#a2d801'
  primary: '#ffffff'
  on-primary: '#263500'
  primary-container: '#bdf532'
  on-primary-container: '#516e00'
  inverse-primary: '#4c6700'
  secondary: '#c2c6d5'
  on-secondary: '#2b303c'
  secondary-container: '#444955'
  on-secondary-container: '#b4b8c7'
  tertiary: '#ffffff'
  on-tertiary: '#253141'
  tertiary-container: '#d6e3f8'
  on-tertiary-container: '#596577'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#bdf532'
  primary-fixed-dim: '#a2d801'
  on-primary-fixed: '#141f00'
  on-primary-fixed-variant: '#384e00'
  secondary-fixed: '#dee2f1'
  secondary-fixed-dim: '#c2c6d5'
  on-secondary-fixed: '#171c26'
  on-secondary-fixed-variant: '#424753'
  tertiary-fixed: '#d6e3f8'
  tertiary-fixed-dim: '#bac7dc'
  on-tertiary-fixed: '#0f1c2b'
  on-tertiary-fixed-variant: '#3b4858'
  background: '#111317'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  title-metric:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  title-metric-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is engineered for elite athletic tracking and uncompromising strength training. The design prioritizes extreme visual clarity, raw athletic focus, and high-velocity interaction. Stripping away decorative noise, the interface serves as a high-contrast performance dashboard calibrated for harsh gym lighting, sweaty one-handed operation, and tunnel-vision workout intensity.

### Design Movement: Technical High-Contrast Minimalism
Drawing from high-performance instrumentation and technical telemetry tools:
- **Utilitarian Speed:** Immediate interaction pathways with 0% cognitive clutter. Key metrics (weight, sets, reps, timers) dominate visual priority.
- **Electric Precision:** A deep void canvas paired with a singular energetic volt-lime accent gives definitive state clarity. An interaction is either idle, actively pending, or dominated and completed.
- **Physical Ergonomics:** Oversized tactile hit zones, bold tabular numeric readouts, and immediate feedback states satisfy the physical realities of high-strain gym use.

## Colors

The color palette centers on extreme tonal isolation. By grounding the entire visual space in an obsidian-slate environment, the singular electric lime accent commands absolute focus.

### Palette Architecture
- **Primary (`#C6FF3D`):** Kinetic electric lime. Reserved exclusively for actionable primaries, active state rings, complete/success states, telemetry meters, and key toggles.
- **Secondary (`#212631`):** Elevated structural slate. Used for nested workout item cards, stepper hit zones, active secondary containers, and elevated utility controls.
- **Tertiary (`#8E9BAE`):** Steel gray. Handles secondary labels, units (kg/lbs, reps, rpe), rest timer countdowns, and placeholder text.
- **Neutral / Canvas (`#0F1115`):** Deep void black-slate. Minimizes OLED display power draw while ensuring infinite contrast against lighter cards and neon accents.
- **Surface Level 1 (`#181B22`):** Primary card backdrop for grouped sets, workout routine cards, and dashboard tiles.
- **Borders & Dividers (`#2A303C`):** Razor-thin, crisp structural lines separating metrics without muddying background depth.
- **Pure White (`#FFFFFF`):** High-impact typographic weight for current metrics, active exercise names, and completed set data.

## Typography

The typographic hierarchy utilizes Inter across all weights, calibrated for dense information architecture and instant glanceability across a training room.

- **Tabular Numerics (`tnum`):** All weight, rep count, rest timer, and set counters must enforce font-variant-numeric: tabular-nums. This prevents jitter during active timer updates and keeps multi-set rows perfectly aligned.
- **Metric Scaling:** Numeric input values (`title-metric`) are visibly weighted above text descriptions to prioritize weight and repetition telemetry at arm’s length.
- **Uppercase Micro-Labels:** `label-sm` enforces uppercase transformation with relaxed tracking (`0.08em`) to delineate secondary labels (e.g., "PREV", "LBS", "KG", "TARGET", "REST") from user data values.

## Layout & Spacing

The layout philosophy utilizes a condensed, high-density fluid grid system designed around finger reachability and one-handed thumb ergonomics.

### Grid & Breakpoints
- **Mobile (< 640px):** Single-column stacked telemetry flow. Outer margins locked to `1rem` to maximize logging surface area. Primary action triggers docked to the bottom safe zone.
- **Tablet & Desktop (≥ 640px):** 12-column grid layout where exercise groups occupy 6 or 8 columns and active performance telemetry/rest countdown docks into a fixed 4-column sidebar.

### Touch Targets & Spatial Rules
- Touch targets for logging rows, stepper buttons, and set checkboxes must maintain an absolute minimum height and width of `48px`.
- Vertical rhythm strictly adheres to multiples of `4px` (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 24px, `space-xl` = 40px).
- Set rows within an exercise card feature compact vertical padding (`0.5rem`) balanced by robust horizontal hit margins.

## Elevation & Depth

This design system avoids traditional blurry drop shadows in favor of a structural, light-emitting dark architectural hierarchy.

### Depth Hierarchy
- **Level 0 (Canvas):** Pure `#0F1115`. Infinite void background.
- **Level 1 (Card Surfaces):** `#181B22` with a uniform `1px` solid border in `#2A303C`. This forms the primary boundary for exercises, history blocks, and modal overlays.
- **Level 2 (Nested Cells & Inputs):** `#212631` embedded into Level 1 surfaces. Creates an extruded, tactile inset for editable metrics, stepper controls, and previous set reminders.
- **Level 3 (Electric Focus / Active):** Borders transitioning to `#C6FF3D` on focus or set completion, accompanied by a subtle ambient glow: `0 0 20px rgba(198, 255, 61, 0.15)`.

## Shapes

The design system standardizes on a `16px` (`rounded-lg` / level 2) structural curvature for cards, sheet panels, and active containers, conveying precision engineering with smooth industrial transitions.

- **Primary Cards & Modals:** `16px` border-radius (`1rem`).
- **Interactive Controls (Inputs, Steppers, Chips):** `12px` border-radius (`0.75rem`) for compact internal containment.
- **Pills & Status Dots:** Fully circular (`rounded-full` or `9999px`) reserved specifically for completed checkmarks, timer badges, and state tags.

## Components

### 1. Buttons
- **Primary CTA:** Background `#C6FF3D`, text `#0F1115`, font weight bold (`700`). Minimum height 52px on mobile. No border. On active press: scale down to `0.98` with high-luminance feedback.
- **Secondary / Action Steppers:** Background `#212631`, border `1px` solid `#2A303C`, text `#FFFFFF`. Large tactile icons (`+` / `-`) centered within a `48x48px` hit frame.
- **Ghost Utility:** Background transparent, text `#8E9BAE`. On hover/active: text shifts to `#FFFFFF` with background `#181B22`.

### 2. Set Checkboxes & Complete States
- **Idle State:** 48x48px touch zone with a 28x28px visible box. Border `2px` solid `#2A303C`, background `#212631`, rounded-md.
- **Completed State:** Background transitions to `#C6FF3D`, border `#C6FF3D`, displaying a dark `#0F1115` checkmark icon. Row text subtly dims or locks to confirm data entry.

### 3. Metric Input Fields & Numeric Steppers
- Input containers built on `#212631` with `#2A303C` border and `12px` border-radius.
- Internal text uses `title-metric` (`tnum`) in `#FFFFFF`. Units (`LBS`, `KG`, `REPS`) positioned inline as fixed `#8E9BAE` label indicators.
- Stepper decrement/increment keys flank the numeric input to enable rapid one-tap adjustments without requiring the software keyboard.

### 4. Cards & Workout Blocks
- Constructed with `#181B22` background, `16px` radius, and `1px` `#2A303C` border.
- Header row contains exercise name (`headline-md`, white) and quick metadata chips (e.g., "3 SETS", "RPE 8").
- Interior displays set column titles in `label-sm` (`#8E9BAE`) followed by high-density horizontal rows.

### 5. Telemetry Badges & Chips
- Status indicators (PR, Warmup, Drop Set, Failure) rendered as high-contrast pills.
- Warmup/Notes: Background `#212631`, text `#8E9BAE`.
- Personal Record (PR): Border `1px` solid `#C6FF3D`, text `#C6FF3D`, background `rgba(198, 255, 61, 0.08)`.

### 6. Rest Timer & Floating Action Drawer
- Persistent floating pill docked at the bottom center during active workouts.
- Dark backdrop `#181B22` with a progress outline in `#C6FF3D`. Features tabular digital countdown text in `#C6FF3D` and quick-add intervals (+30s).